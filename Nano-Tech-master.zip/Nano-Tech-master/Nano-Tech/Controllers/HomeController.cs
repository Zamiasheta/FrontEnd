﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Nano_Tech.Controllers;
using Nano_Tech.Models;
namespace Nano_Tech.Controllers
{
    public class HomeController : Controller
    {
        nanotechfinalEntities1 db = new nanotechfinalEntities1();
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
        public ActionResult allproductpage()
        {   var productlist = db.products.ToList();
            return View(productlist);
        }
    }
}