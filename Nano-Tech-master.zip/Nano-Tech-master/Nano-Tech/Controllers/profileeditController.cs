﻿using System;
using Nano_Tech.Models;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Nano_Tech.Controllers
{
    public class profileeditController : Controller
    {   
        // GET: profileedit
        public ActionResult profileedit()
        {
            return View();
        }
    }
}